import {Text, View} from "react-native";
import * as React from "react";

const FavoriteScreen = () => {
    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Favorite Screens</Text>
        </View>
    );
}

export default FavoriteScreen;