import {Text, View} from "react-native";
import * as React from "react";

const PeopleScreen = () => {
    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>People Screen</Text>
        </View>
    );
}

export default PeopleScreen;