import {Text, View} from "react-native";
import * as React from "react";

const HomeScreen = () => {

     return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Article Screen</Text>
        </View>
    );
}

export default HomeScreen;