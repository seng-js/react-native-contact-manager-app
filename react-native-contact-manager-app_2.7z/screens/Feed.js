import {Text, View} from "react-native";
import * as React from "react";

const Feed = () => {
    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Feed Screen</Text>
        </View>
    );
}


export default Feed;