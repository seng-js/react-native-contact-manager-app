import {Text, View} from "react-native";
import * as React from "react";

const ContactScreen = () => {
    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Contact Screen</Text>
        </View>
    );
}

export default ContactScreen;