import {Text, View} from "react-native";
import * as React from "react";

const CompanyScreen = () => {
    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Company Screen</Text>
        </View>
    );
}

export default CompanyScreen;